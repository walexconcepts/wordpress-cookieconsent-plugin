===Lawful Cookie Consent===
Contributors: Awodeyi Adewale Emmanuel
Donate link: https://izzumes.com/ 
Tags: cookie consent, gdcpr, ccpa, responsive cookie banner, cookie consent, cookie banner, cookie law, cookie notice, EU cookie law
Requires at least: 5.4
Tested up to: 6.1.1
Stable tag: 2.0
Requires PHP: 5.2.4
License: GPLv2 or later
License URI: http://www.gnu.org/licenses/gpl-2.0.html

It is great-looking and responsive, and absolutely free!. Lawful cookie consent is the interaction on your website that enables users to decide whether they will allow cookies to collect their personal data

== Description ==
<p>
It is great-looking and responsive, and absolutely free!. Lawful cookie consent is the interaction on your website that enables users to decide whether they will allow cookies to collect their personal data.
Visit [demo](https://walexconcepts.com/wordpress/).
</p>

Main features:
<p>
<ul>
<li>* Lawful Cookie Consent looks responsive on any device. It is fully customisable, and absolutely free!</li>
<li>* You can use it as simple lawful cookie consent with admin options to configure backgroud color, button background, button text color and position .</li>
<li>* The Lawful Cookie Consent displays results in automatically Popup window with simple text and button.</li>
<li>* Use 'lawful_cookie_consent' menu at admin page for configuration.</li>
</ul>
</p>

== Installation ==
<p>
<ul>
<li>1. Upload files of lawful_cookie_consent to the `/wp-content/plugins/`</li> 
<li>2. Activate the plugin through the 'Plugins' menu in WordPress</li>
<li>3. At backend, click 'lawful_cookie_consent' menu in WordPress to open lawful cookie consent admin page.</li>
<li>4. No Shotcode or Widget required</li>
</ul>
</p>

== Frequently Asked Questions ==
= Does Lawful Cookie Consent work with any Wordpress theme? =

Yes, it does. You can use it with any Wordpress theme.

= Do I get free support for this free plugin? = 
Yes, we can provide support via email and chat if needed. 

== Screenshots ==
1. Screenshot-1 Lawful cokie consent admin page configuration or back-end 
2. Screenshot-2 Front-end - Results popup with text and button
3. Screenshot-3 Responsive layout - mobile
4. Screenshot-4 Responsive layout - tablet  
 

== Changelog ==
<p>
<ul>
= 1.0 =
<li>* roll out (April, 05, 2022)</li>
</ul>
</p>
